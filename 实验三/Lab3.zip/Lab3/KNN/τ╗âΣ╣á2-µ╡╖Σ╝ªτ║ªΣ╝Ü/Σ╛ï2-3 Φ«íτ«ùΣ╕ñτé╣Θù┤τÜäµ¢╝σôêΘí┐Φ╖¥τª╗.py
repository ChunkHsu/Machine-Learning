# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 19:08:07 2020

@author: Harry
"""

from numpy import*
m = mat([1,2,3])
n = mat([4,5,6])
print(sum(abs(m-n)))
