# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 19:09:22 2020

@author: Harry
"""

from numpy import*
a = mat([1,2,3])
b = mat([4,5,6])
print(abs(a-b).max())
