# -*- coding: utf-8 -*-
"""
Created on Tue Sep  8 19:07:08 2020

@author: Harry
"""

from numpy import*
v1 = mat([1,2])
v2 = mat([3,4])
print(sqrt((v1-v2)*(v1-v2).T))
